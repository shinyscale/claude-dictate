#!/usr/bin/env python3
"""
Claude Dictate - Voice-to-Text Tool for Claude Code
A local dictation tool using whisper.cpp with optional LLM refinement.
"""

import os
import sys
import json
import wave
import tempfile
import subprocess
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Optional, Callable
import pyaudio
import keyboard
import pyperclip
import requests

# Configuration
CONFIG = {
    "whisper_cpp_path": "",  # Path to whisper.cpp main executable
    "whisper_model": "base.en",  # Model to use (tiny, base, small, medium, large)
    "sample_rate": 16000,
    "channels": 1,
    "chunk_size": 1024,
    "hotkey": "ctrl+shift",  # Hold to record
    "ollama_url": "http://localhost:11434",
    "lm_studio_url": "http://localhost:1234/v1",
    "default_llm": "ollama",  # ollama or lm_studio
    "default_model": "llama3.2",  # Default model for refinement
    "output_dir": "./outputs",
}


class AudioRecorder:
    """Handles audio recording with push-to-talk functionality."""
    
    def __init__(self, sample_rate: int = 16000, channels: int = 1, chunk_size: int = 1024):
        self.sample_rate = sample_rate
        self.channels = channels
        self.chunk_size = chunk_size
        self.audio = pyaudio.PyAudio()
        self.stream = None
        self.frames = []
        self.is_recording = False
        self.record_thread = None
        
    def start_recording(self):
        """Start recording audio."""
        if self.is_recording:
            return
            
        self.frames = []
        self.is_recording = True
        
        self.stream = self.audio.open(
            format=pyaudio.paInt16,
            channels=self.channels,
            rate=self.sample_rate,
            input=True,
            frames_per_buffer=self.chunk_size
        )
        
        self.record_thread = threading.Thread(target=self._record_loop)
        self.record_thread.start()
        
    def _record_loop(self):
        """Recording loop that runs in a separate thread."""
        while self.is_recording:
            try:
                data = self.stream.read(self.chunk_size, exception_on_overflow=False)
                self.frames.append(data)
            except Exception as e:
                print(f"Recording error: {e}")
                break
                
    def stop_recording(self) -> Optional[str]:
        """Stop recording and return path to WAV file."""
        if not self.is_recording:
            return None
            
        self.is_recording = False
        
        if self.record_thread:
            self.record_thread.join(timeout=1.0)
            
        if self.stream:
            self.stream.stop_stream()
            self.stream.close()
            self.stream = None
            
        if not self.frames:
            return None
            
        # Save to temporary WAV file
        temp_file = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
        with wave.open(temp_file.name, 'wb') as wf:
            wf.setnchannels(self.channels)
            wf.setsampwidth(self.audio.get_sample_size(pyaudio.paInt16))
            wf.setframerate(self.sample_rate)
            wf.writeframes(b''.join(self.frames))
            
        return temp_file.name
        
    def cleanup(self):
        """Clean up audio resources."""
        self.is_recording = False
        if self.stream:
            self.stream.stop_stream()
            self.stream.close()
        self.audio.terminate()


class WhisperTranscriber:
    """Handles transcription using whisper.cpp."""
    
    def __init__(self, whisper_path: str = "", model: str = "base.en"):
        self.whisper_path = whisper_path or self._find_whisper()
        self.model = model
        self.model_path = self._get_model_path()
        
    def _find_whisper(self) -> str:
        """Try to find whisper.cpp executable."""
        possible_paths = [
            "whisper",
            "./whisper",
            "~/whisper.cpp/main",
            "~/whisper.cpp/build/bin/main",
            "/usr/local/bin/whisper",
            os.path.expanduser("~/.local/bin/whisper"),
        ]
        
        for path in possible_paths:
            expanded = os.path.expanduser(path)
            if os.path.isfile(expanded) and os.access(expanded, os.X_OK):
                return expanded
                
        # Check if whisper-cpp is installed via pip
        try:
            result = subprocess.run(["which", "whisper-cpp"], capture_output=True, text=True)
            if result.returncode == 0:
                return result.stdout.strip()
        except:
            pass
            
        return ""
        
    def _get_model_path(self) -> str:
        """Get the path to the whisper model."""
        model_dirs = [
            os.path.expanduser("~/.cache/whisper"),
            os.path.expanduser("~/whisper.cpp/models"),
            "./models",
        ]
        
        model_filename = f"ggml-{self.model}.bin"
        
        for dir_path in model_dirs:
            model_path = os.path.join(dir_path, model_filename)
            if os.path.isfile(model_path):
                return model_path
                
        return model_filename  # Will need to be downloaded
        
    def transcribe(self, audio_path: str) -> str:
        """Transcribe audio file using whisper.cpp."""
        if not self.whisper_path:
            return self._transcribe_fallback(audio_path)
            
        try:
            cmd = [
                self.whisper_path,
                "-m", self.model_path,
                "-f", audio_path,
                "-otxt",
                "--no-timestamps",
                "-l", "en",
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
            
            if result.returncode == 0:
                # Read the output text file
                txt_path = audio_path + ".txt"
                if os.path.isfile(txt_path):
                    with open(txt_path, 'r') as f:
                        text = f.read().strip()
                    os.unlink(txt_path)
                    return text
                return result.stdout.strip()
            else:
                print(f"Whisper error: {result.stderr}")
                return self._transcribe_fallback(audio_path)
                
        except subprocess.TimeoutExpired:
            print("Transcription timed out")
            return ""
        except Exception as e:
            print(f"Transcription error: {e}")
            return self._transcribe_fallback(audio_path)
            
    def _transcribe_fallback(self, audio_path: str) -> str:
        """Fallback transcription using openai-whisper Python package."""
        try:
            import whisper
            model = whisper.load_model(self.model.replace(".en", ""))
            result = model.transcribe(audio_path, language="en")
            return result["text"].strip()
        except ImportError:
            print("Neither whisper.cpp nor openai-whisper found.")
            print("Install whisper.cpp or run: pip install openai-whisper")
            return ""
        except Exception as e:
            print(f"Fallback transcription error: {e}")
            return ""


class LLMRefiner:
    """Handles text refinement using local LLMs."""
    
    def __init__(self, backend: str = "ollama", base_url: str = "", model: str = "llama3.2"):
        self.backend = backend
        self.model = model
        
        if backend == "ollama":
            self.base_url = base_url or "http://localhost:11434"
        else:  # lm_studio
            self.base_url = base_url or "http://localhost:1234/v1"
            
    def refine(self, text: str, style: str = "clean") -> str:
        """Refine transcribed text using LLM."""
        prompts = {
            "clean": """Clean up this transcribed speech. Fix grammar, remove filler words (um, uh, like, you know), and improve readability while preserving the original meaning and tone. Do not add any commentary or explanation, just output the refined text.

Transcription:
{text}

Refined text:""",
            
            "professional": """Transform this transcribed speech into professional, polished writing. Fix grammar, remove filler words, improve clarity, and make it suitable for professional communication. Preserve the key points and meaning. Do not add any commentary, just output the refined text.

Transcription:
{text}

Professional version:""",

            "technical": """Clean up this transcribed speech for technical documentation. Fix grammar, remove filler words, use precise technical language, and format for clarity. Preserve all technical details. Do not add any commentary, just output the refined text.

Transcription:
{text}

Technical version:""",

            "casual": """Clean up this transcribed speech while keeping a casual, conversational tone. Fix obvious errors but preserve the natural speaking style. Do not add any commentary, just output the refined text.

Transcription:
{text}

Casual version:""",
        }
        
        prompt = prompts.get(style, prompts["clean"]).format(text=text)
        
        if self.backend == "ollama":
            return self._refine_ollama(prompt)
        else:
            return self._refine_openai_compatible(prompt)
            
    def _refine_ollama(self, prompt: str) -> str:
        """Refine using Ollama API."""
        try:
            response = requests.post(
                f"{self.base_url}/api/generate",
                json={
                    "model": self.model,
                    "prompt": prompt,
                    "stream": False,
                    "options": {
                        "temperature": 0.3,
                        "num_predict": 2048,
                    }
                },
                timeout=60
            )
            
            if response.status_code == 200:
                return response.json().get("response", "").strip()
            else:
                print(f"Ollama error: {response.status_code} - {response.text}")
                return ""
                
        except requests.exceptions.ConnectionError:
            print("Could not connect to Ollama. Is it running?")
            return ""
        except Exception as e:
            print(f"Ollama refinement error: {e}")
            return ""
            
    def _refine_openai_compatible(self, prompt: str) -> str:
        """Refine using OpenAI-compatible API (LM Studio)."""
        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                json={
                    "model": self.model,
                    "messages": [
                        {"role": "user", "content": prompt}
                    ],
                    "temperature": 0.3,
                    "max_tokens": 2048,
                },
                timeout=60
            )
            
            if response.status_code == 200:
                return response.json()["choices"][0]["message"]["content"].strip()
            else:
                print(f"LM Studio error: {response.status_code} - {response.text}")
                return ""
                
        except requests.exceptions.ConnectionError:
            print("Could not connect to LM Studio. Is it running?")
            return ""
        except Exception as e:
            print(f"LM Studio refinement error: {e}")
            return ""
            
    def check_connection(self) -> bool:
        """Check if the LLM backend is available."""
        try:
            if self.backend == "ollama":
                response = requests.get(f"{self.base_url}/api/tags", timeout=5)
            else:
                response = requests.get(f"{self.base_url}/models", timeout=5)
            return response.status_code == 200
        except:
            return False


class OutputGenerator:
    """Generates output files in various formats."""
    
    def __init__(self, output_dir: str = "./outputs"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
    def generate_filename(self, prefix: str = "dictation", ext: str = "md") -> str:
        """Generate a unique filename with timestamp."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return f"{prefix}_{timestamp}.{ext}"
        
    def save_markdown(self, text: str, title: str = "", filename: str = "") -> str:
        """Save text as a markdown file."""
        if not filename:
            filename = self.generate_filename("dictation", "md")
            
        filepath = self.output_dir / filename
        
        content = f"""# {title or 'Dictation'}

{text}

---
*Generated by Claude Dictate on {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}*
"""
        
        with open(filepath, 'w') as f:
            f.write(content)
            
        return str(filepath)
        
    def save_prd(self, text: str, title: str = "", filename: str = "") -> str:
        """Save text as a PRD (Product Requirements Document) markdown file for Claude Code."""
        if not filename:
            filename = self.generate_filename("prd", "md")
            
        filepath = self.output_dir / filename
        
        # PRD format compatible with Claude Code workflows
        content = f"""# {title or 'Product Requirements Document'}

## Overview

{text}

## User Stories

<!-- Add user stories based on the requirements above -->

- [ ] As a user, I want to...

## Technical Requirements

<!-- Technical implementation details -->

## Success Criteria

<!-- Define what "done" looks like -->

- [ ] All requirements implemented
- [ ] Tests passing
- [ ] Documentation updated

## Notes

---
*Generated by Claude Dictate on {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}*
*Compatible with Claude Code and Ralph Wiggum workflow*
"""
        
        with open(filepath, 'w') as f:
            f.write(content)
            
        return str(filepath)
        
    def save_prompt(self, text: str, title: str = "", filename: str = "") -> str:
        """Save text as a prompt file for Claude Code."""
        if not filename:
            filename = self.generate_filename("prompt", "md")
            
        filepath = self.output_dir / filename
        
        content = f"""# {title or 'Claude Code Prompt'}

{text}

---
## Completion Criteria

When complete, output: <promise>DONE</promise>

## Process

1. Analyze the requirements above
2. Plan the implementation
3. Execute step by step
4. Verify each step works
5. Test the final result

---
*Generated by Claude Dictate on {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}*
"""
        
        with open(filepath, 'w') as f:
            f.write(content)
            
        return str(filepath)
        
    def save_claude_command(self, text: str, command_name: str = "custom") -> str:
        """Save as a Claude Code custom slash command."""
        commands_dir = Path.home() / ".claude" / "commands"
        commands_dir.mkdir(parents=True, exist_ok=True)
        
        filename = f"{command_name.lower().replace(' ', '-')}.md"
        filepath = commands_dir / filename
        
        with open(filepath, 'w') as f:
            f.write(text)
            
        return str(filepath)


class ClaudeDictate:
    """Main application class."""
    
    def __init__(self, config: dict = None):
        self.config = config or CONFIG.copy()
        self.recorder = AudioRecorder(
            sample_rate=self.config["sample_rate"],
            channels=self.config["channels"],
            chunk_size=self.config["chunk_size"]
        )
        self.transcriber = WhisperTranscriber(
            whisper_path=self.config.get("whisper_cpp_path", ""),
            model=self.config.get("whisper_model", "base.en")
        )
        self.refiner = LLMRefiner(
            backend=self.config.get("default_llm", "ollama"),
            model=self.config.get("default_model", "llama3.2")
        )
        self.output_gen = OutputGenerator(
            output_dir=self.config.get("output_dir", "./outputs")
        )
        
        self.current_transcription = ""
        self.current_refined = ""
        self.is_running = False
        
        # Callbacks for UI updates
        self.on_recording_start: Optional[Callable] = None
        self.on_recording_stop: Optional[Callable] = None
        self.on_transcription_complete: Optional[Callable[[str], None]] = None
        self.on_refinement_complete: Optional[Callable[[str], None]] = None
        self.on_status_update: Optional[Callable[[str], None]] = None
        
    def start_recording(self):
        """Start audio recording."""
        if self.on_status_update:
            self.on_status_update("Recording...")
        if self.on_recording_start:
            self.on_recording_start()
        self.recorder.start_recording()
        
    def stop_recording(self) -> str:
        """Stop recording and transcribe."""
        if self.on_status_update:
            self.on_status_update("Processing...")
        if self.on_recording_stop:
            self.on_recording_stop()
            
        audio_path = self.recorder.stop_recording()
        
        if not audio_path:
            if self.on_status_update:
                self.on_status_update("No audio recorded")
            return ""
            
        # Transcribe
        if self.on_status_update:
            self.on_status_update("Transcribing...")
            
        self.current_transcription = self.transcriber.transcribe(audio_path)
        
        # Clean up temp file
        try:
            os.unlink(audio_path)
        except:
            pass
            
        if self.on_transcription_complete:
            self.on_transcription_complete(self.current_transcription)
            
        if self.on_status_update:
            self.on_status_update("Ready")
            
        return self.current_transcription
        
    def refine_text(self, text: str = None, style: str = "clean") -> str:
        """Refine text using LLM."""
        text = text or self.current_transcription
        
        if not text:
            return ""
            
        if self.on_status_update:
            self.on_status_update("Refining with LLM...")
            
        self.current_refined = self.refiner.refine(text, style)
        
        if self.on_refinement_complete:
            self.on_refinement_complete(self.current_refined)
            
        if self.on_status_update:
            self.on_status_update("Ready")
            
        return self.current_refined
        
    def copy_to_clipboard(self, text: str = None):
        """Copy text to clipboard."""
        text = text or self.current_refined or self.current_transcription
        if text:
            pyperclip.copy(text)
            if self.on_status_update:
                self.on_status_update("Copied to clipboard!")
                
    def save_as_markdown(self, text: str = None, title: str = "") -> str:
        """Save as markdown file."""
        text = text or self.current_refined or self.current_transcription
        if text:
            path = self.output_gen.save_markdown(text, title)
            if self.on_status_update:
                self.on_status_update(f"Saved: {path}")
            return path
        return ""
        
    def save_as_prd(self, text: str = None, title: str = "") -> str:
        """Save as PRD file."""
        text = text or self.current_refined or self.current_transcription
        if text:
            path = self.output_gen.save_prd(text, title)
            if self.on_status_update:
                self.on_status_update(f"Saved: {path}")
            return path
        return ""
        
    def save_as_prompt(self, text: str = None, title: str = "") -> str:
        """Save as prompt file for Claude Code."""
        text = text or self.current_refined or self.current_transcription
        if text:
            path = self.output_gen.save_prompt(text, title)
            if self.on_status_update:
                self.on_status_update(f"Saved: {path}")
            return path
        return ""
        
    def setup_hotkey(self, hotkey: str = None):
        """Setup the push-to-talk hotkey."""
        hotkey = hotkey or self.config["hotkey"]
        
        keyboard.on_press_key(hotkey.split('+')[-1], 
            lambda e: self.start_recording() if keyboard.is_pressed(hotkey.split('+')[0]) else None,
            suppress=False
        )
        keyboard.on_release_key(hotkey.split('+')[-1],
            lambda e: self.stop_recording(),
            suppress=False
        )
        
    def cleanup(self):
        """Clean up resources."""
        self.recorder.cleanup()
        keyboard.unhook_all()


def main():
    """CLI entry point."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Claude Dictate - Voice-to-Text for Claude Code")
    parser.add_argument("--gui", action="store_true", help="Launch GUI mode")
    parser.add_argument("--record", action="store_true", help="Record and transcribe once")
    parser.add_argument("--refine", type=str, help="Refine text from file or stdin")
    parser.add_argument("--style", type=str, default="clean", 
                       choices=["clean", "professional", "technical", "casual"],
                       help="Refinement style")
    parser.add_argument("--output", type=str, choices=["md", "prd", "prompt", "clipboard"],
                       default="clipboard", help="Output format")
    parser.add_argument("--llm", type=str, choices=["ollama", "lm_studio"],
                       default="ollama", help="LLM backend")
    parser.add_argument("--model", type=str, default="llama3.2", help="LLM model name")
    
    args = parser.parse_args()
    
    if args.gui:
        # Import and run GUI
        from claude_dictate_gui import run_gui
        run_gui()
    elif args.record:
        # Single recording mode
        app = ClaudeDictate()
        print("Press Enter to start recording, Enter again to stop...")
        input()
        app.start_recording()
        print("Recording... Press Enter to stop")
        input()
        text = app.stop_recording()
        print(f"\nTranscription:\n{text}")
        
        if args.refine:
            print("\nRefining...")
            refined = app.refine_text(text, args.style)
            print(f"\nRefined:\n{refined}")
            text = refined
            
        if args.output == "clipboard":
            app.copy_to_clipboard(text)
            print("\nCopied to clipboard!")
        elif args.output == "md":
            path = app.save_as_markdown(text)
            print(f"\nSaved to: {path}")
        elif args.output == "prd":
            path = app.save_as_prd(text)
            print(f"\nSaved to: {path}")
        elif args.output == "prompt":
            path = app.save_as_prompt(text)
            print(f"\nSaved to: {path}")
            
        app.cleanup()
    else:
        # Default: launch GUI
        try:
            from claude_dictate_gui import run_gui
            run_gui()
        except ImportError:
            print("GUI dependencies not found. Run with --record for CLI mode.")
            print("Install GUI dependencies: pip install customtkinter")


if __name__ == "__main__":
    main()
