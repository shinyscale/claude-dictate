#!/usr/bin/env python3
"""
Claude Dictate GUI - Modern interface for voice-to-text
Uses CustomTkinter for a clean, modern look
"""

import customtkinter as ctk
from tkinter import filedialog, messagebox
import threading
import os
import sys
from pathlib import Path

# Import main module
from claude_dictate import ClaudeDictate, CONFIG

# Theme Configuration
THEME = {
    "bg_dark": "#0D0D0D",
    "bg_medium": "#1A1A1A",
    "bg_light": "#262626",
    "accent": "#FF6B35",
    "accent_hover": "#FF8555",
    "accent_secondary": "#4ECDC4",
    "text_primary": "#FFFFFF",
    "text_secondary": "#A0A0A0",
    "text_muted": "#666666",
    "success": "#4CAF50",
    "warning": "#FFC107",
    "error": "#F44336",
    "border": "#333333",
}

# Font Configuration
FONTS = {
    "title": ("SF Pro Display", 28, "bold"),
    "heading": ("SF Pro Display", 18, "bold"),
    "body": ("SF Pro Text", 14),
    "small": ("SF Pro Text", 12),
    "mono": ("JetBrains Mono", 13),
}


class WaveformCanvas(ctk.CTkCanvas):
    """Animated waveform visualization for recording."""
    
    def __init__(self, master, **kwargs):
        super().__init__(master, bg=THEME["bg_medium"], highlightthickness=0, **kwargs)
        self.is_active = False
        self.bars = []
        self.bar_count = 40
        self.animation_id = None
        self._create_bars()
        
    def _create_bars(self):
        """Create waveform bars."""
        self.update_idletasks()
        width = self.winfo_width() or 400
        height = self.winfo_height() or 60
        bar_width = width / self.bar_count
        
        self.bars = []
        for i in range(self.bar_count):
            x = i * bar_width + bar_width / 4
            bar = self.create_rectangle(
                x, height / 2 - 2,
                x + bar_width / 2, height / 2 + 2,
                fill=THEME["text_muted"],
                outline=""
            )
            self.bars.append(bar)
            
    def start_animation(self):
        """Start waveform animation."""
        self.is_active = True
        self._animate()
        
    def stop_animation(self):
        """Stop waveform animation."""
        self.is_active = False
        if self.animation_id:
            self.after_cancel(self.animation_id)
        self._reset_bars()
        
    def _animate(self):
        """Animate waveform bars."""
        import random
        
        if not self.is_active:
            return
            
        height = self.winfo_height() or 60
        
        for i, bar in enumerate(self.bars):
            # Generate pseudo-random height based on position
            amplitude = random.uniform(0.1, 1.0)
            bar_height = int(amplitude * (height * 0.8))
            
            x1, _, x2, _ = self.coords(bar)
            y_center = height / 2
            
            self.coords(bar, x1, y_center - bar_height/2, x2, y_center + bar_height/2)
            self.itemconfig(bar, fill=THEME["accent"])
            
        self.animation_id = self.after(50, self._animate)
        
    def _reset_bars(self):
        """Reset bars to idle state."""
        height = self.winfo_height() or 60
        
        for bar in self.bars:
            x1, _, x2, _ = self.coords(bar)
            y_center = height / 2
            self.coords(bar, x1, y_center - 2, x2, y_center + 2)
            self.itemconfig(bar, fill=THEME["text_muted"])


class StatusIndicator(ctk.CTkFrame):
    """Status indicator with animated dot."""
    
    def __init__(self, master, **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)
        
        self.dot = ctk.CTkLabel(
            self,
            text="●",
            font=("SF Pro Display", 12),
            text_color=THEME["text_muted"]
        )
        self.dot.pack(side="left", padx=(0, 8))
        
        self.label = ctk.CTkLabel(
            self,
            text="Ready",
            font=FONTS["small"],
            text_color=THEME["text_secondary"]
        )
        self.label.pack(side="left")
        
    def set_status(self, status: str, color: str = None):
        """Update status display."""
        self.label.configure(text=status)
        
        if "recording" in status.lower():
            self.dot.configure(text_color=THEME["error"])
        elif "processing" in status.lower() or "transcribing" in status.lower():
            self.dot.configure(text_color=THEME["warning"])
        elif "ready" in status.lower():
            self.dot.configure(text_color=THEME["success"])
        elif color:
            self.dot.configure(text_color=color)


class TextEditor(ctk.CTkFrame):
    """Text editor panel with toolbar."""
    
    def __init__(self, master, title: str, **kwargs):
        super().__init__(master, fg_color=THEME["bg_light"], corner_radius=12, **kwargs)
        
        # Header
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.pack(fill="x", padx=16, pady=(16, 8))
        
        ctk.CTkLabel(
            header,
            text=title,
            font=FONTS["heading"],
            text_color=THEME["text_primary"]
        ).pack(side="left")
        
        # Text area
        self.textbox = ctk.CTkTextbox(
            self,
            font=FONTS["mono"],
            fg_color=THEME["bg_medium"],
            text_color=THEME["text_primary"],
            border_width=1,
            border_color=THEME["border"],
            corner_radius=8,
            wrap="word"
        )
        self.textbox.pack(fill="both", expand=True, padx=16, pady=(0, 16))
        
    def get_text(self) -> str:
        """Get text content."""
        return self.textbox.get("1.0", "end-1c")
        
    def set_text(self, text: str):
        """Set text content."""
        self.textbox.delete("1.0", "end")
        self.textbox.insert("1.0", text)
        
    def clear(self):
        """Clear text content."""
        self.textbox.delete("1.0", "end")


class SettingsPanel(ctk.CTkToplevel):
    """Settings window."""
    
    def __init__(self, master, config: dict, on_save=None):
        super().__init__(master)
        
        self.config = config.copy()
        self.on_save = on_save
        
        self.title("Settings")
        self.geometry("500x600")
        self.configure(fg_color=THEME["bg_dark"])
        
        # Make modal
        self.transient(master)
        self.grab_set()
        
        self._create_widgets()
        
    def _create_widgets(self):
        """Create settings widgets."""
        # Header
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.pack(fill="x", padx=24, pady=(24, 16))
        
        ctk.CTkLabel(
            header,
            text="Settings",
            font=FONTS["title"],
            text_color=THEME["text_primary"]
        ).pack(anchor="w")
        
        # Scrollable content
        content = ctk.CTkScrollableFrame(
            self,
            fg_color="transparent"
        )
        content.pack(fill="both", expand=True, padx=24)
        
        # Whisper Settings
        self._add_section(content, "Whisper Configuration")
        
        self.whisper_path_var = ctk.StringVar(value=self.config.get("whisper_cpp_path", ""))
        self._add_entry(content, "Whisper Path:", self.whisper_path_var, 
                       placeholder="Auto-detect or enter path")
        
        self.model_var = ctk.StringVar(value=self.config.get("whisper_model", "base.en"))
        self._add_dropdown(content, "Model:", self.model_var,
                          ["tiny.en", "base.en", "small.en", "medium.en", "large"])
        
        # LLM Settings
        self._add_section(content, "LLM Configuration")
        
        self.llm_backend_var = ctk.StringVar(value=self.config.get("default_llm", "ollama"))
        self._add_dropdown(content, "Backend:", self.llm_backend_var,
                          ["ollama", "lm_studio"])
        
        self.llm_model_var = ctk.StringVar(value=self.config.get("default_model", "llama3.2"))
        self._add_entry(content, "Model:", self.llm_model_var,
                       placeholder="e.g., llama3.2, mistral")
        
        self.ollama_url_var = ctk.StringVar(value=self.config.get("ollama_url", "http://localhost:11434"))
        self._add_entry(content, "Ollama URL:", self.ollama_url_var)
        
        self.lm_studio_url_var = ctk.StringVar(value=self.config.get("lm_studio_url", "http://localhost:1234/v1"))
        self._add_entry(content, "LM Studio URL:", self.lm_studio_url_var)
        
        # Hotkey Settings
        self._add_section(content, "Controls")
        
        self.hotkey_var = ctk.StringVar(value=self.config.get("hotkey", "ctrl+shift"))
        self._add_entry(content, "Hold-to-Talk:", self.hotkey_var,
                       placeholder="e.g., ctrl+shift")
        
        # Output Settings
        self._add_section(content, "Output")
        
        self.output_dir_var = ctk.StringVar(value=self.config.get("output_dir", "./outputs"))
        self._add_entry(content, "Output Directory:", self.output_dir_var)
        
        # Buttons
        buttons = ctk.CTkFrame(self, fg_color="transparent")
        buttons.pack(fill="x", padx=24, pady=24)
        
        ctk.CTkButton(
            buttons,
            text="Cancel",
            font=FONTS["body"],
            fg_color="transparent",
            border_width=1,
            border_color=THEME["border"],
            hover_color=THEME["bg_light"],
            command=self.destroy
        ).pack(side="right", padx=(8, 0))
        
        ctk.CTkButton(
            buttons,
            text="Save",
            font=FONTS["body"],
            fg_color=THEME["accent"],
            hover_color=THEME["accent_hover"],
            command=self._save
        ).pack(side="right")
        
    def _add_section(self, parent, title: str):
        """Add section header."""
        ctk.CTkLabel(
            parent,
            text=title,
            font=FONTS["heading"],
            text_color=THEME["text_primary"]
        ).pack(anchor="w", pady=(24, 12))
        
    def _add_entry(self, parent, label: str, variable: ctk.StringVar, placeholder: str = ""):
        """Add labeled entry field."""
        frame = ctk.CTkFrame(parent, fg_color="transparent")
        frame.pack(fill="x", pady=6)
        
        ctk.CTkLabel(
            frame,
            text=label,
            font=FONTS["body"],
            text_color=THEME["text_secondary"]
        ).pack(anchor="w")
        
        ctk.CTkEntry(
            frame,
            textvariable=variable,
            font=FONTS["body"],
            fg_color=THEME["bg_light"],
            border_color=THEME["border"],
            placeholder_text=placeholder,
            height=36
        ).pack(fill="x", pady=(4, 0))
        
    def _add_dropdown(self, parent, label: str, variable: ctk.StringVar, values: list):
        """Add labeled dropdown."""
        frame = ctk.CTkFrame(parent, fg_color="transparent")
        frame.pack(fill="x", pady=6)
        
        ctk.CTkLabel(
            frame,
            text=label,
            font=FONTS["body"],
            text_color=THEME["text_secondary"]
        ).pack(anchor="w")
        
        ctk.CTkComboBox(
            frame,
            variable=variable,
            values=values,
            font=FONTS["body"],
            fg_color=THEME["bg_light"],
            border_color=THEME["border"],
            button_color=THEME["accent"],
            button_hover_color=THEME["accent_hover"],
            dropdown_fg_color=THEME["bg_medium"],
            height=36
        ).pack(fill="x", pady=(4, 0))
        
    def _save(self):
        """Save settings."""
        self.config["whisper_cpp_path"] = self.whisper_path_var.get()
        self.config["whisper_model"] = self.model_var.get()
        self.config["default_llm"] = self.llm_backend_var.get()
        self.config["default_model"] = self.llm_model_var.get()
        self.config["ollama_url"] = self.ollama_url_var.get()
        self.config["lm_studio_url"] = self.lm_studio_url_var.get()
        self.config["hotkey"] = self.hotkey_var.get()
        self.config["output_dir"] = self.output_dir_var.get()
        
        if self.on_save:
            self.on_save(self.config)
            
        self.destroy()


class ClaudeDictateGUI(ctk.CTk):
    """Main application window."""
    
    def __init__(self):
        super().__init__()
        
        # Configure window
        self.title("Claude Dictate")
        self.geometry("1100x800")
        self.configure(fg_color=THEME["bg_dark"])
        
        # Set appearance
        ctk.set_appearance_mode("dark")
        
        # Initialize app
        self.config = CONFIG.copy()
        self.app = ClaudeDictate(self.config)
        self._setup_callbacks()
        
        # State
        self.is_recording = False
        self.current_style = "clean"
        
        # Create UI
        self._create_layout()
        self._bind_hotkey()
        
    def _setup_callbacks(self):
        """Setup application callbacks."""
        self.app.on_recording_start = self._on_recording_start
        self.app.on_recording_stop = self._on_recording_stop
        self.app.on_transcription_complete = self._on_transcription_complete
        self.app.on_refinement_complete = self._on_refinement_complete
        self.app.on_status_update = self._on_status_update
        
    def _create_layout(self):
        """Create the main layout."""
        # Header
        self._create_header()
        
        # Main content
        content = ctk.CTkFrame(self, fg_color="transparent")
        content.pack(fill="both", expand=True, padx=24, pady=(0, 24))
        
        # Left panel - Recording controls
        left_panel = ctk.CTkFrame(content, fg_color=THEME["bg_light"], corner_radius=12, width=340)
        left_panel.pack(side="left", fill="y", padx=(0, 16))
        left_panel.pack_propagate(False)
        self._create_control_panel(left_panel)
        
        # Right panel - Text editors
        right_panel = ctk.CTkFrame(content, fg_color="transparent")
        right_panel.pack(side="left", fill="both", expand=True)
        self._create_editor_panel(right_panel)
        
    def _create_header(self):
        """Create header with title and settings."""
        header = ctk.CTkFrame(self, fg_color="transparent", height=80)
        header.pack(fill="x", padx=24, pady=(24, 16))
        header.pack_propagate(False)
        
        # Logo and title
        title_frame = ctk.CTkFrame(header, fg_color="transparent")
        title_frame.pack(side="left")
        
        ctk.CTkLabel(
            title_frame,
            text="◉",
            font=("SF Pro Display", 32),
            text_color=THEME["accent"]
        ).pack(side="left", padx=(0, 12))
        
        ctk.CTkLabel(
            title_frame,
            text="Claude Dictate",
            font=FONTS["title"],
            text_color=THEME["text_primary"]
        ).pack(side="left")
        
        # Settings button
        ctk.CTkButton(
            header,
            text="⚙",
            font=("SF Pro Display", 20),
            width=44,
            height=44,
            fg_color="transparent",
            hover_color=THEME["bg_light"],
            command=self._open_settings
        ).pack(side="right")
        
        # Status indicator
        self.status = StatusIndicator(header)
        self.status.pack(side="right", padx=24)
        
    def _create_control_panel(self, parent):
        """Create recording control panel."""
        # Title
        ctk.CTkLabel(
            parent,
            text="Voice Input",
            font=FONTS["heading"],
            text_color=THEME["text_primary"]
        ).pack(anchor="w", padx=20, pady=(20, 8))
        
        ctk.CTkLabel(
            parent,
            text=f"Hold {self.config['hotkey']} or click button",
            font=FONTS["small"],
            text_color=THEME["text_muted"]
        ).pack(anchor="w", padx=20, pady=(0, 16))
        
        # Waveform visualization
        self.waveform = WaveformCanvas(parent, height=80)
        self.waveform.pack(fill="x", padx=20, pady=(0, 20))
        
        # Record button
        self.record_btn = ctk.CTkButton(
            parent,
            text="🎤 Hold to Record",
            font=FONTS["body"],
            height=56,
            fg_color=THEME["accent"],
            hover_color=THEME["accent_hover"],
            corner_radius=28
        )
        self.record_btn.pack(fill="x", padx=20, pady=(0, 24))
        self.record_btn.bind("<ButtonPress-1>", lambda e: self._start_recording())
        self.record_btn.bind("<ButtonRelease-1>", lambda e: self._stop_recording())
        
        # Divider
        ctk.CTkFrame(parent, fg_color=THEME["border"], height=1).pack(fill="x", padx=20, pady=8)
        
        # Refinement options
        ctk.CTkLabel(
            parent,
            text="LLM Refinement",
            font=FONTS["heading"],
            text_color=THEME["text_primary"]
        ).pack(anchor="w", padx=20, pady=(16, 8))
        
        # Style selector
        style_frame = ctk.CTkFrame(parent, fg_color="transparent")
        style_frame.pack(fill="x", padx=20, pady=(0, 12))
        
        self.style_var = ctk.StringVar(value="clean")
        styles = [
            ("Clean", "clean"),
            ("Professional", "professional"),
            ("Technical", "technical"),
            ("Casual", "casual"),
        ]
        
        for i, (label, value) in enumerate(styles):
            ctk.CTkRadioButton(
                style_frame,
                text=label,
                variable=self.style_var,
                value=value,
                font=FONTS["small"],
                fg_color=THEME["accent"],
                hover_color=THEME["accent_hover"]
            ).pack(anchor="w", pady=4)
            
        # Refine button
        self.refine_btn = ctk.CTkButton(
            parent,
            text="✨ Refine with LLM",
            font=FONTS["body"],
            height=44,
            fg_color=THEME["accent_secondary"],
            hover_color="#6EDDD4",
            command=self._refine_text
        )
        self.refine_btn.pack(fill="x", padx=20, pady=(8, 24))
        
        # Divider
        ctk.CTkFrame(parent, fg_color=THEME["border"], height=1).pack(fill="x", padx=20, pady=8)
        
        # Export options
        ctk.CTkLabel(
            parent,
            text="Export",
            font=FONTS["heading"],
            text_color=THEME["text_primary"]
        ).pack(anchor="w", padx=20, pady=(16, 12))
        
        export_btns = ctk.CTkFrame(parent, fg_color="transparent")
        export_btns.pack(fill="x", padx=20)
        
        ctk.CTkButton(
            export_btns,
            text="📋 Copy",
            font=FONTS["small"],
            width=85,
            height=36,
            fg_color=THEME["bg_medium"],
            hover_color=THEME["bg_dark"],
            command=self._copy_to_clipboard
        ).pack(side="left", padx=(0, 8))
        
        ctk.CTkButton(
            export_btns,
            text="📝 .md",
            font=FONTS["small"],
            width=85,
            height=36,
            fg_color=THEME["bg_medium"],
            hover_color=THEME["bg_dark"],
            command=self._save_markdown
        ).pack(side="left", padx=(0, 8))
        
        ctk.CTkButton(
            export_btns,
            text="📄 .prd",
            font=FONTS["small"],
            width=85,
            height=36,
            fg_color=THEME["bg_medium"],
            hover_color=THEME["bg_dark"],
            command=self._save_prd
        ).pack(side="left")
        
        # Prompt button
        ctk.CTkButton(
            parent,
            text="🚀 Save as Claude Code Prompt",
            font=FONTS["small"],
            height=36,
            fg_color=THEME["bg_medium"],
            hover_color=THEME["bg_dark"],
            command=self._save_prompt
        ).pack(fill="x", padx=20, pady=(12, 20))
        
    def _create_editor_panel(self, parent):
        """Create text editor panels."""
        # Top editor - Raw transcription
        self.raw_editor = TextEditor(parent, "Raw Transcription")
        self.raw_editor.pack(fill="both", expand=True, pady=(0, 8))
        
        # Bottom editor - Refined text
        self.refined_editor = TextEditor(parent, "Refined Text")
        self.refined_editor.pack(fill="both", expand=True, pady=(8, 0))
        
    def _bind_hotkey(self):
        """Bind keyboard hotkey for recording."""
        try:
            import keyboard
            
            hotkey = self.config["hotkey"]
            
            # For compound hotkeys like "ctrl+shift"
            keyboard.add_hotkey(hotkey, self._start_recording, suppress=False, trigger_on_release=False)
            keyboard.on_release_key(hotkey.split('+')[-1], lambda e: self._stop_recording() if self.is_recording else None)
            
        except Exception as e:
            print(f"Could not bind hotkey: {e}")
            
    def _start_recording(self):
        """Start recording."""
        if self.is_recording:
            return
            
        self.is_recording = True
        self.record_btn.configure(text="🔴 Recording...", fg_color=THEME["error"])
        self.waveform.start_animation()
        
        # Start recording in background
        threading.Thread(target=self.app.start_recording, daemon=True).start()
        
    def _stop_recording(self):
        """Stop recording and transcribe."""
        if not self.is_recording:
            return
            
        self.is_recording = False
        self.record_btn.configure(text="🎤 Hold to Record", fg_color=THEME["accent"])
        self.waveform.stop_animation()
        
        # Stop recording in background
        threading.Thread(target=self.app.stop_recording, daemon=True).start()
        
    def _refine_text(self):
        """Refine transcribed text with LLM."""
        text = self.raw_editor.get_text()
        if not text.strip():
            return
            
        style = self.style_var.get()
        
        def refine():
            self.app.refine_text(text, style)
            
        threading.Thread(target=refine, daemon=True).start()
        
    def _copy_to_clipboard(self):
        """Copy refined or raw text to clipboard."""
        text = self.refined_editor.get_text() or self.raw_editor.get_text()
        if text.strip():
            self.app.copy_to_clipboard(text)
            
    def _save_markdown(self):
        """Save as markdown file."""
        text = self.refined_editor.get_text() or self.raw_editor.get_text()
        if text.strip():
            path = self.app.save_as_markdown(text)
            if path:
                messagebox.showinfo("Saved", f"Saved to:\n{path}")
                
    def _save_prd(self):
        """Save as PRD file."""
        text = self.refined_editor.get_text() or self.raw_editor.get_text()
        if text.strip():
            path = self.app.save_as_prd(text)
            if path:
                messagebox.showinfo("Saved", f"Saved to:\n{path}")
                
    def _save_prompt(self):
        """Save as Claude Code prompt."""
        text = self.refined_editor.get_text() or self.raw_editor.get_text()
        if text.strip():
            path = self.app.save_as_prompt(text)
            if path:
                messagebox.showinfo("Saved", f"Saved to:\n{path}")
                
    def _open_settings(self):
        """Open settings panel."""
        SettingsPanel(self, self.config, self._on_settings_save)
        
    def _on_settings_save(self, new_config: dict):
        """Handle settings save."""
        self.config.update(new_config)
        
        # Reinitialize app with new config
        self.app.cleanup()
        self.app = ClaudeDictate(self.config)
        self._setup_callbacks()
        
        # Rebind hotkey
        try:
            import keyboard
            keyboard.unhook_all()
        except:
            pass
        self._bind_hotkey()
        
    # Callbacks
    def _on_recording_start(self):
        """Called when recording starts."""
        pass
        
    def _on_recording_stop(self):
        """Called when recording stops."""
        pass
        
    def _on_transcription_complete(self, text: str):
        """Called when transcription is complete."""
        self.after(0, lambda: self.raw_editor.set_text(text))
        
    def _on_refinement_complete(self, text: str):
        """Called when refinement is complete."""
        self.after(0, lambda: self.refined_editor.set_text(text))
        
    def _on_status_update(self, status: str):
        """Called when status updates."""
        self.after(0, lambda: self.status.set_status(status))
        
    def on_closing(self):
        """Handle window close."""
        self.app.cleanup()
        try:
            import keyboard
            keyboard.unhook_all()
        except:
            pass
        self.destroy()


def run_gui():
    """Run the GUI application."""
    app = ClaudeDictateGUI()
    app.protocol("WM_DELETE_WINDOW", app.on_closing)
    app.mainloop()


if __name__ == "__main__":
    run_gui()
