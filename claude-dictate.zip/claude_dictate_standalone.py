#!/usr/bin/env python3
"""
Claude Dictate - Standalone Version
A simplified single-file dictation tool for Claude Code workflows.

Features:
- Hold-to-record with keyboard shortcut
- Local transcription via whisper (Python package)
- Optional LLM refinement via Ollama/LM Studio
- Export to .md, .prd, or clipboard

Usage:
    python claude_dictate_standalone.py

Dependencies:
    pip install pyaudio keyboard pyperclip requests openai-whisper

Note: This version uses the Python whisper package as fallback when whisper.cpp
is not available. For faster transcription, install whisper.cpp.
"""

import os
import sys
import wave
import tempfile
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Optional
import json

try:
    import pyaudio
except ImportError:
    print("Missing dependency: pip install pyaudio")
    sys.exit(1)

try:
    import keyboard
except ImportError:
    print("Missing dependency: pip install keyboard")
    sys.exit(1)

try:
    import pyperclip
except ImportError:
    print("Missing dependency: pip install pyperclip")
    sys.exit(1)

try:
    import requests
except ImportError:
    print("Missing dependency: pip install requests")
    sys.exit(1)


# ═══════════════════════════════════════════════════════════════════════════════
# Configuration
# ═══════════════════════════════════════════════════════════════════════════════

DEFAULT_CONFIG = {
    "sample_rate": 16000,
    "channels": 1,
    "chunk_size": 1024,
    "hotkey": "ctrl+shift+space",  # Hold to record
    "whisper_model": "base",  # tiny, base, small, medium, large
    "llm_backend": "ollama",  # ollama or lm_studio
    "llm_model": "llama3.2",
    "ollama_url": "http://localhost:11434",
    "lm_studio_url": "http://localhost:1234/v1",
    "output_dir": "./dictation_outputs",
}


# ═══════════════════════════════════════════════════════════════════════════════
# Audio Recorder
# ═══════════════════════════════════════════════════════════════════════════════

class AudioRecorder:
    """Simple push-to-talk audio recorder."""
    
    def __init__(self, sample_rate=16000, channels=1, chunk_size=1024):
        self.sample_rate = sample_rate
        self.channels = channels
        self.chunk_size = chunk_size
        self.audio = pyaudio.PyAudio()
        self.stream = None
        self.frames = []
        self.is_recording = False
        
    def start(self):
        """Start recording."""
        if self.is_recording:
            return
            
        self.frames = []
        self.is_recording = True
        
        try:
            self.stream = self.audio.open(
                format=pyaudio.paInt16,
                channels=self.channels,
                rate=self.sample_rate,
                input=True,
                frames_per_buffer=self.chunk_size
            )
        except Exception as e:
            print(f"❌ Could not open microphone: {e}")
            self.is_recording = False
            return
            
        # Record in background thread
        def record():
            while self.is_recording:
                try:
                    data = self.stream.read(self.chunk_size, exception_on_overflow=False)
                    self.frames.append(data)
                except:
                    break
                    
        threading.Thread(target=record, daemon=True).start()
        
    def stop(self) -> Optional[str]:
        """Stop recording and return path to WAV file."""
        if not self.is_recording:
            return None
            
        self.is_recording = False
        time.sleep(0.1)  # Let recording thread finish
        
        if self.stream:
            self.stream.stop_stream()
            self.stream.close()
            self.stream = None
            
        if not self.frames:
            return None
            
        # Save to temp WAV file
        temp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
        with wave.open(temp.name, 'wb') as wf:
            wf.setnchannels(self.channels)
            wf.setsampwidth(self.audio.get_sample_size(pyaudio.paInt16))
            wf.setframerate(self.sample_rate)
            wf.writeframes(b''.join(self.frames))
            
        return temp.name
        
    def cleanup(self):
        """Release audio resources."""
        if self.stream:
            self.stream.close()
        self.audio.terminate()


# ═══════════════════════════════════════════════════════════════════════════════
# Whisper Transcriber
# ═══════════════════════════════════════════════════════════════════════════════

class Transcriber:
    """Transcription using OpenAI Whisper."""
    
    def __init__(self, model_name="base"):
        self.model_name = model_name
        self.model = None
        
    def _load_model(self):
        """Lazy load the whisper model."""
        if self.model is None:
            try:
                import whisper
                print(f"📦 Loading Whisper model '{self.model_name}'...")
                self.model = whisper.load_model(self.model_name)
                print("✓ Model loaded")
            except ImportError:
                print("❌ Whisper not installed. Run: pip install openai-whisper")
                return False
        return True
        
    def transcribe(self, audio_path: str) -> str:
        """Transcribe audio file to text."""
        if not self._load_model():
            return ""
            
        try:
            result = self.model.transcribe(audio_path, language="en", fp16=False)
            return result["text"].strip()
        except Exception as e:
            print(f"❌ Transcription error: {e}")
            return ""


# ═══════════════════════════════════════════════════════════════════════════════
# LLM Refiner
# ═══════════════════════════════════════════════════════════════════════════════

REFINEMENT_PROMPTS = {
    "clean": """Clean up this transcribed speech. Fix grammar, remove filler words (um, uh, like), and improve readability. Preserve the original meaning and tone. Output ONLY the refined text, no explanation.

Transcription: {text}

Refined:""",

    "professional": """Transform this transcribed speech into professional writing. Fix grammar, remove filler words, use clear professional language. Output ONLY the refined text.

Transcription: {text}

Professional version:""",

    "technical": """Refine this for technical documentation. Fix grammar, use precise technical language, preserve all technical details. Output ONLY the refined text.

Transcription: {text}

Technical version:""",

    "bullets": """Convert this transcribed speech into clear bullet points. Output ONLY the bullet points.

Transcription: {text}

Bullet points:""",

    "prompt": """Convert this transcribed speech into a clear, actionable prompt for Claude Code. Structure it with clear requirements. Output ONLY the prompt.

Transcription: {text}

Claude Code prompt:""",
}


class LLMRefiner:
    """Text refinement using local LLMs."""
    
    def __init__(self, backend="ollama", model="llama3.2", 
                 ollama_url="http://localhost:11434",
                 lm_studio_url="http://localhost:1234/v1"):
        self.backend = backend
        self.model = model
        self.ollama_url = ollama_url
        self.lm_studio_url = lm_studio_url
        
    def refine(self, text: str, style: str = "clean") -> str:
        """Refine text using LLM."""
        prompt = REFINEMENT_PROMPTS.get(style, REFINEMENT_PROMPTS["clean"]).format(text=text)
        
        if self.backend == "ollama":
            return self._call_ollama(prompt)
        else:
            return self._call_lm_studio(prompt)
            
    def _call_ollama(self, prompt: str) -> str:
        """Call Ollama API."""
        try:
            response = requests.post(
                f"{self.ollama_url}/api/generate",
                json={
                    "model": self.model,
                    "prompt": prompt,
                    "stream": False,
                    "options": {"temperature": 0.3}
                },
                timeout=60
            )
            if response.status_code == 200:
                return response.json().get("response", "").strip()
            else:
                print(f"❌ Ollama error: {response.status_code}")
                return ""
        except requests.exceptions.ConnectionError:
            print("❌ Cannot connect to Ollama. Is it running? (ollama serve)")
            return ""
        except Exception as e:
            print(f"❌ Ollama error: {e}")
            return ""
            
    def _call_lm_studio(self, prompt: str) -> str:
        """Call LM Studio API (OpenAI compatible)."""
        try:
            response = requests.post(
                f"{self.lm_studio_url}/chat/completions",
                json={
                    "model": self.model,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": 0.3,
                    "max_tokens": 2048
                },
                timeout=60
            )
            if response.status_code == 200:
                return response.json()["choices"][0]["message"]["content"].strip()
            else:
                print(f"❌ LM Studio error: {response.status_code}")
                return ""
        except requests.exceptions.ConnectionError:
            print("❌ Cannot connect to LM Studio. Is the server running?")
            return ""
        except Exception as e:
            print(f"❌ LM Studio error: {e}")
            return ""
            
    def is_available(self) -> bool:
        """Check if LLM backend is available."""
        try:
            if self.backend == "ollama":
                r = requests.get(f"{self.ollama_url}/api/tags", timeout=2)
            else:
                r = requests.get(f"{self.lm_studio_url}/models", timeout=2)
            return r.status_code == 200
        except:
            return False


# ═══════════════════════════════════════════════════════════════════════════════
# Output Generator
# ═══════════════════════════════════════════════════════════════════════════════

class OutputGenerator:
    """Generate output files."""
    
    def __init__(self, output_dir="./dictation_outputs"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
    def _filename(self, prefix: str, ext: str) -> str:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return f"{prefix}_{timestamp}.{ext}"
        
    def save_markdown(self, text: str, title: str = "Dictation") -> str:
        """Save as markdown file."""
        filename = self._filename("dictation", "md")
        filepath = self.output_dir / filename
        
        content = f"""# {title}

{text}

---
*Generated by Claude Dictate - {datetime.now().strftime("%Y-%m-%d %H:%M")}*
"""
        filepath.write_text(content)
        return str(filepath)
        
    def save_prd(self, text: str, title: str = "Requirements") -> str:
        """Save as PRD markdown file."""
        filename = self._filename("prd", "md")
        filepath = self.output_dir / filename
        
        content = f"""# {title}

## Overview

{text}

## User Stories

- [ ] As a user, I want to...

## Technical Requirements

<!-- Add technical details -->

## Success Criteria

- [ ] All requirements implemented
- [ ] Tests passing
- [ ] Documentation updated

---
*Generated by Claude Dictate - {datetime.now().strftime("%Y-%m-%d %H:%M")}*
*Compatible with Claude Code workflows*
"""
        filepath.write_text(content)
        return str(filepath)
        
    def save_prompt(self, text: str, title: str = "Task") -> str:
        """Save as Claude Code prompt file."""
        filename = self._filename("prompt", "md")
        filepath = self.output_dir / filename
        
        content = f"""# {title}

{text}

---

## Completion Criteria

When complete, output: <promise>DONE</promise>

## Process

1. Analyze the requirements
2. Plan the implementation
3. Execute step by step
4. Test the result
5. Document decisions

---
*Generated by Claude Dictate*
*Ready for /ralph-loop or direct use*
"""
        filepath.write_text(content)
        return str(filepath)


# ═══════════════════════════════════════════════════════════════════════════════
# Main Application
# ═══════════════════════════════════════════════════════════════════════════════

class ClaudeDictate:
    """Main dictation application."""
    
    def __init__(self, config: dict = None):
        self.config = config or DEFAULT_CONFIG.copy()
        
        self.recorder = AudioRecorder(
            sample_rate=self.config["sample_rate"],
            channels=self.config["channels"],
            chunk_size=self.config["chunk_size"]
        )
        
        self.transcriber = Transcriber(model_name=self.config["whisper_model"])
        
        self.refiner = LLMRefiner(
            backend=self.config["llm_backend"],
            model=self.config["llm_model"],
            ollama_url=self.config["ollama_url"],
            lm_studio_url=self.config["lm_studio_url"]
        )
        
        self.output = OutputGenerator(output_dir=self.config["output_dir"])
        
        self.current_text = ""
        self.is_recording = False
        
    def start_recording(self):
        """Start recording audio."""
        print("\n🔴 Recording... (release hotkey to stop)")
        self.is_recording = True
        self.recorder.start()
        
    def stop_recording(self) -> str:
        """Stop recording and transcribe."""
        if not self.is_recording:
            return ""
            
        self.is_recording = False
        audio_path = self.recorder.stop()
        
        if not audio_path:
            print("⚠️  No audio recorded")
            return ""
            
        print("⏳ Transcribing...")
        self.current_text = self.transcriber.transcribe(audio_path)
        
        # Clean up temp file
        try:
            os.unlink(audio_path)
        except:
            pass
            
        if self.current_text:
            print(f"\n📝 Transcription:\n{self.current_text}\n")
        else:
            print("⚠️  No speech detected")
            
        return self.current_text
        
    def refine_text(self, style: str = "clean") -> str:
        """Refine current text with LLM."""
        if not self.current_text:
            print("⚠️  No text to refine")
            return ""
            
        if not self.refiner.is_available():
            print(f"⚠️  {self.config['llm_backend']} not available")
            return self.current_text
            
        print(f"✨ Refining with {self.config['llm_backend']} ({style})...")
        refined = self.refiner.refine(self.current_text, style)
        
        if refined:
            self.current_text = refined
            print(f"\n📝 Refined:\n{refined}\n")
            
        return self.current_text
        
    def copy_to_clipboard(self):
        """Copy current text to clipboard."""
        if self.current_text:
            pyperclip.copy(self.current_text)
            print("📋 Copied to clipboard!")
            
    def save_markdown(self) -> str:
        """Save as markdown file."""
        if self.current_text:
            path = self.output.save_markdown(self.current_text)
            print(f"💾 Saved: {path}")
            return path
        return ""
        
    def save_prd(self) -> str:
        """Save as PRD file."""
        if self.current_text:
            path = self.output.save_prd(self.current_text)
            print(f"💾 Saved: {path}")
            return path
        return ""
        
    def save_prompt(self) -> str:
        """Save as Claude Code prompt."""
        if self.current_text:
            path = self.output.save_prompt(self.current_text)
            print(f"💾 Saved: {path}")
            return path
        return ""
        
    def cleanup(self):
        """Clean up resources."""
        self.recorder.cleanup()


# ═══════════════════════════════════════════════════════════════════════════════
# Interactive CLI
# ═══════════════════════════════════════════════════════════════════════════════

def print_header():
    """Print application header."""
    print("""
╔═══════════════════════════════════════════════════════════════════════════╗
║                                                                           ║
║   ██████╗██╗      █████╗ ██╗   ██╗██████╗ ███████╗                        ║
║  ██╔════╝██║     ██╔══██╗██║   ██║██╔══██╗██╔════╝                        ║
║  ██║     ██║     ███████║██║   ██║██║  ██║█████╗                          ║
║  ██║     ██║     ██╔══██║██║   ██║██║  ██║██╔══╝                          ║
║  ╚██████╗███████╗██║  ██║╚██████╔╝██████╔╝███████╗                        ║
║   ╚═════╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚══════╝                        ║
║                                                                           ║
║   ██████╗ ██╗ ██████╗████████╗ █████╗ ████████╗███████╗                   ║
║   ██╔══██╗██║██╔════╝╚══██╔══╝██╔══██╗╚══██╔══╝██╔════╝                   ║
║   ██║  ██║██║██║        ██║   ███████║   ██║   █████╗                     ║
║   ██║  ██║██║██║        ██║   ██╔══██║   ██║   ██╔══╝                     ║
║   ██████╔╝██║╚██████╗   ██║   ██║  ██║   ██║   ███████╗                   ║
║   ╚═════╝ ╚═╝ ╚═════╝   ╚═╝   ╚═╝  ╚═╝   ╚═╝   ╚══════╝                   ║
║                                                                           ║
║   Voice-to-Text for Claude Code                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝
""")


def print_help():
    """Print help message."""
    print("""
Commands:
  [r] Record     - Press and hold to record, release to stop
  [e] Refine     - Refine text with LLM
  [c] Copy       - Copy to clipboard
  [m] Save .md   - Save as markdown
  [p] Save .prd  - Save as PRD
  [s] Save prompt- Save as Claude Code prompt
  [q] Quit       - Exit application

Refinement styles (use with 'e'):
  clean       - Fix grammar, remove filler words
  professional- Polish for professional communication
  technical   - Format for technical docs
  bullets     - Convert to bullet points
  prompt      - Format as Claude Code prompt

Hotkey: Hold Ctrl+Shift+Space to record
""")


def run_interactive():
    """Run interactive CLI mode."""
    print_header()
    
    app = ClaudeDictate()
    
    # Check LLM availability
    if app.refiner.is_available():
        print(f"✓ {app.config['llm_backend']} connected ({app.config['llm_model']})")
    else:
        print(f"⚠️  {app.config['llm_backend']} not available (refinement disabled)")
    
    print_help()
    
    # Setup hotkey
    hotkey = app.config["hotkey"]
    recording = False
    
    def on_hotkey_press():
        nonlocal recording
        if not recording:
            recording = True
            app.start_recording()
            
    def on_hotkey_release():
        nonlocal recording
        if recording:
            recording = False
            app.stop_recording()
    
    try:
        keyboard.add_hotkey(hotkey, on_hotkey_press, trigger_on_release=False)
        keyboard.on_release_key(hotkey.split('+')[-1], lambda e: on_hotkey_release())
        print(f"✓ Hotkey registered: {hotkey}")
    except Exception as e:
        print(f"⚠️  Could not register hotkey: {e}")
        print("   (You can still use 'r' to record)")
    
    print("\n" + "="*60)
    print("Ready! Hold hotkey to record or use commands below.")
    print("="*60 + "\n")
    
    try:
        while True:
            cmd = input("\n> ").strip().lower()
            
            if cmd == 'q' or cmd == 'quit':
                break
            elif cmd == 'r' or cmd == 'record':
                print("Press Enter to start, Enter again to stop...")
                input()
                app.start_recording()
                input()
                app.stop_recording()
            elif cmd.startswith('e'):
                # e clean, e professional, etc.
                parts = cmd.split()
                style = parts[1] if len(parts) > 1 else "clean"
                app.refine_text(style)
            elif cmd == 'c' or cmd == 'copy':
                app.copy_to_clipboard()
            elif cmd == 'm' or cmd == 'md':
                app.save_markdown()
            elif cmd == 'p' or cmd == 'prd':
                app.save_prd()
            elif cmd == 's' or cmd == 'save':
                app.save_prompt()
            elif cmd == 'h' or cmd == 'help':
                print_help()
            elif cmd:
                print("Unknown command. Type 'h' for help.")
                
    except KeyboardInterrupt:
        print("\n")
        
    finally:
        print("👋 Goodbye!")
        keyboard.unhook_all()
        app.cleanup()


# ═══════════════════════════════════════════════════════════════════════════════
# Entry Point
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Claude Dictate - Voice-to-Text for Claude Code")
    parser.add_argument("--once", action="store_true", help="Record once and exit")
    parser.add_argument("--refine", type=str, default="", help="Refinement style")
    parser.add_argument("--output", type=str, default="clipboard", 
                       choices=["clipboard", "md", "prd", "prompt"],
                       help="Output format")
    parser.add_argument("--model", type=str, default="base",
                       help="Whisper model (tiny, base, small, medium, large)")
    parser.add_argument("--llm", type=str, default="ollama",
                       choices=["ollama", "lm_studio"],
                       help="LLM backend for refinement")
    parser.add_argument("--llm-model", type=str, default="llama3.2",
                       help="LLM model name")
    
    args = parser.parse_args()
    
    if args.once:
        # Single recording mode
        config = DEFAULT_CONFIG.copy()
        config["whisper_model"] = args.model
        config["llm_backend"] = args.llm
        config["llm_model"] = args.llm_model
        
        app = ClaudeDictate(config)
        
        print("Press Enter to start recording...")
        input()
        app.start_recording()
        print("Recording... Press Enter to stop")
        input()
        app.stop_recording()
        
        if args.refine:
            app.refine_text(args.refine)
            
        if args.output == "clipboard":
            app.copy_to_clipboard()
        elif args.output == "md":
            app.save_markdown()
        elif args.output == "prd":
            app.save_prd()
        elif args.output == "prompt":
            app.save_prompt()
            
        app.cleanup()
    else:
        # Interactive mode
        run_interactive()
